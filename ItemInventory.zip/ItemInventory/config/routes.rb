Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  resources :items

  root "items#index"

  get 'items/new', to: "items#new"

  #get 'items/edit', to: "items#edit", as: "edit_item_path" #prefix url

  get 'items/:id/edit', to: "items#edit"

  get 'items/:id', to: "items#show"

  post 'items', to: "items#create"

  put 'items/:id', to: "items#update"

  delete 'items/:id', to: "items#destroy"

end
